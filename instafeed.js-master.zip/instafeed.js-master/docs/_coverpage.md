# Instafeed.js <small>2.0.0</small>

> A simple Instagram JS plugin for your website.

- Powered by the [Instagram Basic Display API](https://developers.facebook.com/docs/instagram-basic-display-api/)
- Lightweight (12KB minified), with 0 dependencies
- Easily customizable with templating support
- Maintained and supported since 2012

[GitHub](https://github.com/stevenschobert/instafeed.js/)
[Get Started](#installation)

![color](#f0f0f0)
